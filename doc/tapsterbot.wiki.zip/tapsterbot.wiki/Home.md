**Welcome to the tapsterbot wiki!**  

_You can find the original wiki [here](https://github.com/tapsterbot/tapsterbot/wiki "Tapster's GitHub wiki")._

Tapster is a robot which bring automation to your tests. Instead of using software frameworks to make operations on your mobile applications (Selenium, XCUITest, UI Automator or Appium), why not use a robot?

Tapster can make all the basic things a user can do with one finger. Click, swipe, draw, there are a lot of combinations!

Ready to start?